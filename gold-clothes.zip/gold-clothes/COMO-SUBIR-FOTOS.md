# GOLD CLOTHES — Cómo poner las fotos reales

La página ya tiene los 99 productos del catálogo, con nombre, categoría,
colores y precio. Las fotos están pendientes — mientras no las subas,
cada producto muestra un cuadro con el texto "Foto pendiente" y el
nombre de archivo que espera.

## Pasos para agregar las fotos

1. Abre `products.js` y busca el producto que quieras (ej: "Buzo Normal
   Cuello Redondo"). Vas a ver una línea así:

   ```
   {id:1, name:"Buzo Normal Cuello Redondo", ..., img:"productos/001.jpg"}
   ```

2. Esa línea te dice que la foto debe llamarse **001.jpg** y debe ir
   dentro de la carpeta **productos/**.

3. Pon tu foto real en `productos/001.jpg` (puedes usar .jpg, .png o
   .webp — solo asegúrate de que el nombre coincida exactamente, o
   cambia el nombre en products.js para que coincida con tu archivo).

4. Repite para cada producto. El número de archivo siempre coincide
   con el `id` del producto (3 dígitos, con ceros a la izquierda).

5. Sube la página de nuevo a GitHub Pages (o donde la tengas) — no hay
   que tocar el HTML, solo agregar las fotos a la carpeta `productos/`.

## Tip para hacerlo rápido

Si tienes las 99 fotos ya nombradas de otra forma (por ejemplo,
"buzo_negro.jpg"), es más fácil que me las pases junto con cuál id le
corresponde a cada una, y yo actualizo `products.js` con los nombres
reales en vez de que tengas que renombrar 99 archivos a mano.
